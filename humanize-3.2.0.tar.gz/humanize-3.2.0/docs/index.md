# humanize

Welcome to the humanize API reference.

* [Number](number)
* [Time](time)
* [Filesize](filesize)
* [I18n](i18n)

For usage examples see
[README.md](https://github.com/jmoiron/humanize/blob/master/README.md).
